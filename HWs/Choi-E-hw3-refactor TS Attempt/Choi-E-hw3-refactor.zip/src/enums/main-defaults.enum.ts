enum DEFAULTS {
  sound1 = "media/New Adventure Theme.mp3"
}

export { DEFAULTS }